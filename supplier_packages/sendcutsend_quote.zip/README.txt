SendCutSend - Symphonium prototype feasibility/quote request

Proposed material: clear polypropylene, 0.030 inch (0.762 mm). Proposed quantity: 1; optional price for 2.
Upload pachelbel_cut_mm.dxf alone as the manufacturing CAD, millimeters, 1:1.
Expected outside diameter: 177.800 mm; center hole: 5.0800 mm.
143 drive rectangles and 20 round music holes, plus the center hole.
Provide reference_drawing.pdf as a supporting drawing and quote_request.txt as notes.
Extract this ZIP first if the portal expects individual files.
All dimensions are prototype nominals; request supplier review before cutting.
The center-hole fit needs confirmation beyond general cutting tolerances.
This package requests feasibility and pricing; no order has been placed.
Flag any geometry/material substitution before manufacturing.
Cut-file SHA-256: ec4e174329df93d682abef2e0361f3df6db0b5136ccddd760fbc8de70f6110a4
